import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const MusicContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'lyrics' | 'comments' | 'single'>('lyrics');

  return (
    <View style={styles.container}>
      {/* タブ切替ボタン */}
      <View style={styles.tabButtons}>
      <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'single' && styles.activeTabButton,
          ]}
          onPress={() => setActiveTab('single')}
        >
          <Text style={styles.tabButtonText}>シングル</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'lyrics' && styles.activeTabButton,
          ]}
          onPress={() => setActiveTab('lyrics')}
        >
          <Text style={styles.tabButtonText}>歌詞</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'comments' && styles.activeTabButton,
          ]}
          onPress={() => setActiveTab('comments')}
        >
          <Text style={styles.tabButtonText}>コメント</Text>
        </TouchableOpacity>
      </View>

      {/* タブの内容 */}
      <View style={styles.contentContainer}>
        {activeTab === 'lyrics' && (
          <Text style={styles.contentText}>
            ここに歌詞が表示されます。{"\n\n"}
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.{"\n"}
            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.{"\n\n"}
            // ... 長い歌詞テキスト ...
          </Text>
        )}
        {activeTab === 'comments' && (
          <Text style={styles.contentText}>
            ここにコメントが表示されます。{"\n\n"}
            例: 「素晴らしい曲です！」{"\n"}
            「とても感動しました」{"\n\n"}
            // ... 長いコメントリスト ...
          </Text>
        )}
        {activeTab === 'single' && (
          <Text style={styles.contentText}>
            ここにシングルが表示されます。
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabButtons: {
    flexDirection: 'row',
    backgroundColor: '#121212',
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 15,
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#ffffff',
  },
  tabButtonText: {
    color: '#ffffff',
    fontSize: 16,
  },
  contentContainer: {
    padding: 20,
    paddingBottom: 100,
  },
  contentText: {
    color: '#ffffff',
    fontSize: 16,
    lineHeight: 24,
  },
});

export default MusicContent; 