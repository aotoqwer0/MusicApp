// src/components/GenreGrid.tsx
import React, { FC, useMemo } from 'react';
import { ScrollView, View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

type GenreGridProps = {
  genres?: string[];
};

const GenreGrid: FC<GenreGridProps> = ({ genres = [] }) => {
  // デフォルトは8ジャンルの例
  const genreList = genres.length
    ? genres
    : ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

  // 2アイテムずつの配列に変換（横スクロール時、各列が縦2段となる）
  const columns = useMemo(() => {
    const result = [];
    for (let i = 0; i < genreList.length; i += 1) {
      result.push(genreList.slice(i, i + 1));
    }
    return result;
  }, [genreList]);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.scrollContainer}
    >
      {columns.map((column, colIndex) => (
        <View key={colIndex} style={styles.column}>
          {column.map((genre, index) => (
            <TouchableOpacity key={index} activeOpacity={0.8} style={styles.buttonContainer}>
              <LinearGradient
                colors={['#6a11cb', '#2575fc']}
                style={styles.genreButton}
                start={[0, 0]}
                end={[1, 1]}
              >
                <Text style={styles.genreText}>{genre}</Text>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    paddingHorizontal: 10,
  },
  column: {
    flexDirection: 'column',
    marginHorizontal: 5,
  },
  buttonContainer: {
    marginVertical: 10,
  },
  genreButton: {
    width: width * 0.35,
    height: width * 0.35,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    // 立体感を与えるシャドウ設定
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 8,
  },
  genreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GenreGrid;
