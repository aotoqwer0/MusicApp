import React from 'react';
import { View, Text, StyleSheet,ScrollView,Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MusicGenres from '../../components/music/MusicGenres';
import Recommendation from '../../components/music/Recommendation';

export default function HomeScreen() {
  return (
    <SafeAreaView edges={['left', 'right', 'bottom']} style={styles.container}>
      <ScrollView
      vertical
      showsVerticalScrollIndicator={false}
    >
        <View style={styles.header}>
          <Text style={styles.title}>Category</Text>
        </View>
        <View style={styles.content}>
          <MusicGenres />
        </View>
        <View style={styles.header}>
          <Text style={styles.title}>Recommendation</Text>
        </View>
        <View style={styles.content}>
          <Recommendation />
        </View>
        
      </ScrollView>
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212', // ダークテーマ
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 10,     // 上部のパディングを完全に削除
    paddingBottom: 8,  // 下部のパディングを微調整
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',
    marginTop: -1,     // ヘッダーとの隙間をなくす
  },
  content: {
    flex: 1,
    padding: 0,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
});
