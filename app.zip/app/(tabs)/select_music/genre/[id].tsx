import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams } from 'expo-router';
import CircularCarousel from '@/components/music/CircularCarousel';
import { Ionicons } from '@expo/vector-icons';

export default function GenreDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();

  const handleReloadPress = () => {
    console.log(`Reload pressed`); // 後で実装する処理用
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{id}</Text>
      </View>
      <View style={styles.carouselContainer}>
        <CircularCarousel />
      </View>
      <TouchableOpacity style={styles.reload} onPress={() => {handleReloadPress()}} activeOpacity={0.7}>
        <Ionicons name="reload-circle" size={50} color="#666666"/>
      </TouchableOpacity>
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  carouselContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  reload: {
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    padding: 20,
    marginBottom: 60,
  },
}); 