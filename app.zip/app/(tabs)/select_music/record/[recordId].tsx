import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, router } from 'expo-router';
import MusicAlbumArt from '../../../../components/music/MusicAlbumArt';
import MusicToolbar from '../../../../components/music/MusicToolbar';
import MusicContent from '../../../../components/music/MusicContent';
import { Ionicons } from '@expo/vector-icons';

export default function MusicDetailScreen() {
  const { recordId } = useLocalSearchParams<{ recordId: string }>();

  return (
    <SafeAreaView style={styles.container}>
      {/* 戻るボタン */}
      <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
        <Ionicons name="chevron-back" size={30} color="#ffffff" />
      </TouchableOpacity>

      <ScrollView style={styles.scrollContent}>
        {/* ジャケ写コンポーネント */}
        <View style={styles.albumContainer}>
          <MusicAlbumArt recordId={recordId} onInfoPress={() => {}} />
        </View>

        {/* スクロール可能なコンテンツ */}
        <View style={styles.scrollableContent}>
          {/* ツールバーコンポーネント */}
          <MusicToolbar />
          
          {/* 歌詞・コメントコンポーネント */}
          <MusicContent />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  backButton: {
    position: 'absolute',
    top: 20,  // 上部の余白を増やす
    left: 20,
    zIndex: 3,
  },
  scrollContent: {
    flex: 1,
  },
  albumContainer: {
    marginTop: 0,  // 戻るボタンの下に配置
  },
  scrollableContent: {
    marginTop: 0,  // ジャケ写に重なるように上にずらす
    backgroundColor: '#121212',
  },
});